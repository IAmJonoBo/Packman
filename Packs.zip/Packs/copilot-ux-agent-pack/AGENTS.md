# AGENTS

This repo uses `.github/copilot-instructions.md` as the primary Copilot instruction file.
