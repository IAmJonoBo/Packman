# Baseline Scorecard

## Context

- System/domain:
- Constraints and targets:
- Assessment date:

## Standards posture

| Dimension         | Target | Current | Gap | Evidence |
| ----------------- | ------ | ------- | --- | -------- |
| ISO/IEC 25010     |        |         |     |          |
| NIST SSDF         |        |         |     |          |
| OWASP ASVS        |        |         |     |          |
| SLSA              |        |         |     |          |
| OpenSSF Scorecard |        |         |     |          |

## Risk register

| Risk | Severity | Likelihood | Owner | Mitigation | Due |
| ---- | -------- | ---------- | ----- | ---------- | --- |
|      |          |            |       |            |     |
