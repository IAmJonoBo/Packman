# Uplift Slice

## Slice scope

- Problem statement:
- Standard/control mapping:
- Out of scope:

## Change plan (small CL)

1.
2.

## Verification

- Commands/checks:
- Expected result:

## Rollback

- Revert path:
- Data/config implications:

## Completion evidence

- Artifacts/PR:
- Residual risk:
