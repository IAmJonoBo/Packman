---
name: curate-release-notes
description: Curate changelog/release notes for the upcoming release with breaking changes and migration guidance.
agent: "Release Notes Curator"
---

Scope: ${selection}

Output:

- Release notes draft
- Breaking changes + migrations
- Known issues
