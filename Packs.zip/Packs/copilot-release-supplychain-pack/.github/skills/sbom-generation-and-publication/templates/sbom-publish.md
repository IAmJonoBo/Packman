# SBOM Publish Manifest (Template)

- Artifact:
- Version:
- Format: CycloneDX / SPDX
- Generator tool:
- Output path(s):
- Publication location(s):
- Linkage: checksum / digest / release tag
