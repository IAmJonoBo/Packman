# Release Engineering

This folder documents:

- release process
- provenance attestations
- SBOM generation and publication
- artifact verification
- release notes conventions
