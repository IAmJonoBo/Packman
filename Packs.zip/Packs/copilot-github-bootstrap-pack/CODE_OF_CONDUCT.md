# Code of Conduct

This project follows the Contributor Covenant Code of Conduct.

Be respectful. No harassment. Maintain a professional tone.

Enforcement: contact the maintainers.
