# Support

Use the following channels:

- Questions: GitHub Discussions (preferred)
- Bugs: GitHub Issues (use templates)

If you are reporting a security issue, see SECURITY.md.
