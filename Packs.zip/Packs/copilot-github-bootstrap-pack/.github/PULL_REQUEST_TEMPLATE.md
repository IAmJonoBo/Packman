## What / Why

-

## How to test

- [ ] Unit tests
- [ ] Integration tests
- [ ] Manual verification
      Commands / notes:

## Risk & impact

- Risk level: low | medium | high
- Affected areas:

## Docs impact

- [ ] No docs change
- [ ] Docs updated
- [ ] Docs TODO created (link)

## Checklist

- [ ] Tests added/updated where appropriate
- [ ] No secrets committed
- [ ] Breaking changes called out
