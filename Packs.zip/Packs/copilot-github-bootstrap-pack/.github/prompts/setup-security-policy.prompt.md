---
name: setup-security-policy
description: Add/refresh SECURITY.md for responsible vulnerability reporting and response expectations.
agent: "Security Policy Editor"
---

Scope: ${selection}

Output:

- SECURITY.md created/updated
- Reporting channels and timelines
