---
name: community-profile-audit
description: Audit repo community health readiness and propose patches to close gaps.
agent: "Community Health Auditor"
---

Scope: ${selection}

Output:

- Gap list (ranked)
- Fixes applied
- Remaining TODOs
