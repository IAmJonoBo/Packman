---
name: dependabot-policy
description: Add/adjust Dependabot update configuration and triage labels.
agent: "Dependabot Steward"
---

Scope: ${selection}

Output:

- dependabot.yml created/updated
- Schedule and ecosystems
- Labeling strategy
