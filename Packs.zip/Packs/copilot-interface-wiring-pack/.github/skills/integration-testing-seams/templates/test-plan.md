# Integration Test Plan (Template)

## Critical user flow

- Steps:
- Expected UI states:

## Tests

1. Happy path:
2. Recoverable error (retry):
3. Domain/validation error:

## Determinism

- Fixtures:
- Mock strategy:
- Timeouts/backoff controls:
