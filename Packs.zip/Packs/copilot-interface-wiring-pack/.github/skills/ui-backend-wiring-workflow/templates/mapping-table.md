# Endpoint → UI Mapping (Template)

| Endpoint | Purpose | Request type | Response type | Cache key | UI consumers | Error mapping |
| -------- | ------- | ------------ | ------------- | --------- | ------------ | ------------- |
|          |         |              |               |           |              |               |
