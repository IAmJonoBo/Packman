# State Matrix (Template)

| View/Component | Default | Loading | Empty | Error | Success | Retry strategy |
| -------------- | ------- | ------- | ----- | ----- | ------- | -------------- |
|                |         |         |       |       |         |                |
