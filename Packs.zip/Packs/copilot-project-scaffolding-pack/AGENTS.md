# AGENTS

This repo uses `.github/copilot-instructions.md` for Copilot custom instructions.
