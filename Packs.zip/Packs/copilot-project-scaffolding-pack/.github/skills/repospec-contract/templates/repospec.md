# RepoSpec — <repo name>

## 1) Purpose and scope

-

## 2) Profile

- Profile ID:
- Project type:
- Assumptions:

## 3) Toolchains (pinned)

- Node:
- Rust:
- Python:

## 4) Directory layout

(describe)

## 5) Scripts contract

- build:
- test:
- lint:
- fmt:
- typecheck:
- dev:

## 6) CI entry points

- PR checks:
- Release checks:

## 7) Docs skeleton

- tutorials/
- how-to/
- reference/
- explanation/
- glossary.md
- diagrams/

## 8) Release surface

-

## 9) Quality/security posture

-

## 10) Upgrade path

-
