---
name: projen-synth
description: Create/upgrade scaffolding using projen; create .projenrc.* and ensure synth is deterministic.
agent: "Projen Synthesizer"
---

Target: ${selection}

Output:

- projen project type chosen
- .projenrc.\* created/updated
- synth commands
- files synthesised
