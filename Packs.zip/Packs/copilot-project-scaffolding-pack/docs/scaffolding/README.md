# Scaffolding

This folder documents:

- scaffold profile selection
- RepoSpec(s)
- regeneration/synthesis instructions
