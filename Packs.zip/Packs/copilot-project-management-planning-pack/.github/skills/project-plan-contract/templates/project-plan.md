# Project Plan

## Objectives

## Non-goals

## Scope boundaries

## Assumptions and constraints

## Milestones and slices

## Dependencies and critical path

## Risk register summary

## Checkpoint cadence

## Replan triggers and policy

## Decisions and open questions
