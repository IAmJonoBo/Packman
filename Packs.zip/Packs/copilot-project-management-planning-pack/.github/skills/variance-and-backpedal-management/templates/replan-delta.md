# Replan Delta

## Trigger event

## Before and after milestone changes

## Dependency and critical-path changes

## Risk adjustments

## Newly assigned actions
