# Variance Log

## Event

## Type and severity

## Scope and timeline impact

## Risk impact

## Response owner

## Due window
