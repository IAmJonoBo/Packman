# Refactor Plan (Template)

## Goal

-

## Constraints

-

## Steps (small and reversible)

1.
2.
3.

## Verification per step

-

## Rollback plan

-
