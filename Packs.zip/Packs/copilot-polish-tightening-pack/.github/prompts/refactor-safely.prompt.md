---
name: refactor-safely
description: Perform a behaviour-preserving refactor in baby steps, separated from behaviour changes, with verification.
agent: "Refactor Surgeon"
---

Target: ${selection}

Output:

- Refactor plan (steps)
- Files changed
- Verification commands
