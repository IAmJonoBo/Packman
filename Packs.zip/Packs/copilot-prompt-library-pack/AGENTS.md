# AGENTS

This pack is prompt-focused. It does not require custom agents, but can reference them when installed.
