# Typography Scale (Template)

| Token | Size (px/rem) | Weight | Line-height | Letter-spacing | Use |
| ----- | ------------: | -----: | ----------: | -------------: | --- |
|       |               |        |             |                |     |
