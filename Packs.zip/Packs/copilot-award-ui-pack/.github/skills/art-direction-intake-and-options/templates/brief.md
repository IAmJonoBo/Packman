# UI Brief (Template)

- Platform:
- Breakpoints / screen sizes:
- Product context / audience:
- Brand adjectives:
- References:
- Typeface constraints:
- Colour constraints:
- Density:
- Accessibility target:
- Motion:
- Scope (screens/flows):
- Must avoid:
- Success criteria:
