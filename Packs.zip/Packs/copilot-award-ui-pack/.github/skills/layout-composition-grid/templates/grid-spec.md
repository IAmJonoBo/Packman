# Grid Spec (Template)

| Breakpoint | Container | Columns | Gutter | Margin | Notes |
| ---------- | --------: | ------: | -----: | -----: | ----- |
|            |           |         |        |        |       |
