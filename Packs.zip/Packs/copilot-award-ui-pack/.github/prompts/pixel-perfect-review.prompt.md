---
name: pixel-perfect-review
description: Run a ruthless pixel-perfect + a11y + heuristic QA pass and produce exact fixes.
agent: "Pixel QA Reviewer"
---

Target: ${selection}

Output:

- Issues (ranked)
- Exact fixes
- Verification checklist
