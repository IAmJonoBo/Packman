# Copilot Policy Kernel

Always-on repo rules.
