# Incident Timeline (Template)

| Time (UTC) | Event | Who | Notes |
| ---------- | ----- | --- | ----- |
|            |       |     |       |
