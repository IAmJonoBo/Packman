# DORA Worksheet (Template)

## Sources

- Deploy events:
- Code merge events:
- Incident events:

## Definitions

- Deployment frequency:
- Lead time for changes:
- Change fail rate:
- Time to restore service:

## Cadence

- Weekly:
- Monthly:
