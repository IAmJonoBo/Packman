# SLO Table (Template)

| Critical path | SLI | SLO target | Window | Measurement | Notes |
| ------------- | --- | ---------: | ------ | ----------- | ----- |
|               |     |            |        |             |       |
