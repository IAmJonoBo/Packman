# Runbook (Template)

## What is broken?

- Symptom:
- User impact:

## Fast checks

- Dashboard links:
- Logs/trace queries:

## Mitigations (fastest first)

1.
2.
3.

## Verification

- How to confirm recovery:

## Escalation

- Who to page next:
