# Action Items Rubric

Each action item must include:

- Owner:
- Due date:
- Priority:
- Category: prevent / detect / mitigate / process
- Definition of done:
- Verification method:

Bad: “Improve monitoring”
Good: “Add SLO burn-rate alert for X (2%/1h and 5%/6h), with runbook and owner; verify in staging by injecting errors.”
