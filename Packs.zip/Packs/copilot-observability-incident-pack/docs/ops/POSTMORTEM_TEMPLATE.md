# Postmortem (Template)

## Summary

- What happened:
- User impact:
- Duration:
- Severity:

## Timeline

(attach incident timeline)

## Detection

- How detected:
- Why not sooner:

## Root causes

- Primary causes:
- Contributing factors:

## What went well

## What went poorly

## Where we got lucky

## Action items

- (see rubric)
