# Observability

This folder is for:

- instrumentation notes
- SLOs and alerts
- runbooks
- incident timelines and postmortems
