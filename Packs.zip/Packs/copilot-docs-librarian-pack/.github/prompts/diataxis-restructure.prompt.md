---
name: diataxis-restructure
description: Restructure docs to conform to Diátaxis; split mixed-mode pages and cross-link.
agent: "Diátaxis Architect"
---

Target: ${selection}

Output:

- Classification
- Proposed new structure (tree)
- Edits applied (or exact patch plan)
