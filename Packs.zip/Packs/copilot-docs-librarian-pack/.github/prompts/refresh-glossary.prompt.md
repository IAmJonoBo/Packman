---
name: refresh-glossary
description: Update glossary and enforce first-use term definitions and consistent linking.
agent: "Glossary Curator"
---

Target: ${selection}

Output:

- Glossary entries added/updated
- Terms fixed in docs (first-use expansion + links)
