# Glossary

## A

- **API** — Application Programming Interface.

## D

- **Diátaxis** — A documentation framework with four modes: tutorial, how-to, reference, explanation.
