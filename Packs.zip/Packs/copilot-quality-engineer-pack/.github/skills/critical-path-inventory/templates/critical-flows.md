# Critical Flows (Template)

| Flow | User goal | Preconditions | Steps (high level) | Expected result | Tests (links) |
| ---- | --------- | ------------- | ------------------ | --------------- | ------------- |
|      |           |               |                    |                 |               |
