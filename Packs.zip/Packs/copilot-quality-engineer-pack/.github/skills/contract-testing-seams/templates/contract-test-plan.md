# Contract Test Plan (Template)

- Boundary:
- Provider:
- Consumer:
- Schema source:
- Compatibility rules:
- Tests:
  - happy path
  - breaking-change check
  - error envelope check
