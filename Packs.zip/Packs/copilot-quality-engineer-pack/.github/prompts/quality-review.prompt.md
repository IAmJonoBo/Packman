---
name: quality-review
description: "Review a change for quality gates: tests prove behaviour, determinism, critical path coverage, and maintainability."
agent: "Quality Gate Reviewer"
---

Target: ${selection}

Output:

- Findings (ranked)
- Required fixes
- Verification steps
