# Security Gatekeeper Notes

Use this pack to threat-model and ASVS-map changes before shipping.
