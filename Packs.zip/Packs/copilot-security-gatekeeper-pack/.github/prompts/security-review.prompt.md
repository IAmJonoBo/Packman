---
name: security-review
description: Perform a security-focused review and produce a concrete fix list with patches.
agent: "Security Reviewer"
---

Target: ${selection}

Output:

- Findings (ranked)
- Exact fixes (file/line guidance)
- Verification steps
