# Threat Model Worksheet

## Scope

- Feature/endpoints:
- Assets/data:
- Trust boundaries:
- Entry points:

## STRIDE

| Threat | Scenario | Impact | Likelihood | Mitigation | Verification |
| ------ | -------- | -----: | ---------: | ---------- | ------------ |
|        |          |        |            |            |              |

## Abuse cases

- Abuse case 1:
- Abuse case 2:

## Notes

- Assumptions:
- Open questions:
