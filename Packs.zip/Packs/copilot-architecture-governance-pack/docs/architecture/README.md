# Architecture & Governance

This folder is for:

- ADRs: `docs/architecture/adr/`
- Decision index: `docs/architecture/adr/README.md`
- Governance checklists and review rubrics
