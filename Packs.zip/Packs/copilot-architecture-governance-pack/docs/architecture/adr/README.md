# Architecture Decision Records (ADR Index)

| ADR | Title | Status | Date | Notes |
| --- | ----- | ------ | ---- | ----- |
|     |       |        |      |       |
