---
name: trunk-slice
description: Convert a large change into small mergeable slices and recommend flags/branch strategy.
agent: "Trunk Coach"
---

Scope: ${selection}

Output:

- Slice plan (ordered)
- Flagging/rollback strategy
- Merge sequencing
