---
name: governance-review
description: Review a change against governance gates and code review standards; produce a fix list.
agent: "Code Review Marshal"
---

Target: ${selection}

Output:

- Findings (ranked)
- Required fixes
- Verification steps
