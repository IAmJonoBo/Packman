---
name: pr-template-and-review-contract
description: Create a PR template that forces verification and documents risk, scope, and docs impact.
---

# PR Template + Review Contract

## Must include

- What/why
- How to test
- Risk/impact
- Docs impact
- Checklist for maintainers
