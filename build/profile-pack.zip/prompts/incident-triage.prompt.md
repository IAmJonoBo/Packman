---
name: "brief:incident-triage"
description: >-
  Produce an incident response playbook for this repo/service and a
  live-incident checklist.
agent: Incident Commander Coach
---

Scope: ${selection}

Output:

- Roles + comms plan
- Triage checklist
- Timeline capture template
- Resolution + verification steps
