---
name: "brief:write-adr"
description: >-
  Write/update a Nygard-style ADR for the selected change and update the ADR
  index.
agent: ADR Writer
---

Target: ${selection}

Output:

- ADR file path
- Summary (context/decision/consequences)
- Alternatives considered
- Follow-ups
