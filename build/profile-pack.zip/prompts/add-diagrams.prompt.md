---
name: "brief:add-diagrams"
description: >-
  Add Mermaid diagrams for flows/state/sequence/architecture to cover the target
  documentation area.
agent: Diagram Curator
---

Target: ${selection}

Output:

- Diagrams added (type + purpose)
- Where they live in docs
- How they map to code paths
