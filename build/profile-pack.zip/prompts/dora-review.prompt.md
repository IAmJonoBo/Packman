---
name: "brief:dora-review"
description: Define DORA metrics data sources and how to compute/report them for this repo.
agent: DORA Reporter
---

Scope: ${selection}

Output:

- Metric definitions
- Data sources
- Collection approach
- Review cadence
