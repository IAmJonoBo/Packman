---
name: "brief:write-postmortem"
description: Create or refine a blame-free postmortem template and action-item standards.
agent: Postmortem Editor
---

Scope: ${selection}

Output:

- Postmortem template
- Action item rubric
- Sharing + follow-up process
