---
name: "brief:nit-sweep"
description: Identify and rank high-impact “nits that matter” in the selected area.
agent: Nit Hunter
---

Target: ${selection}

Output:

- Ranked list (impact vs effort)
- Suggested slice plan
