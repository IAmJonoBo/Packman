---
name: "brief:slice-small-cls"
description: >-
  Convert a large improvement idea into small mergeable slices; separate
  refactors from behaviour changes.
agent: Small-CL Slicer
---

Scope: ${selection}

Output:

- Slice list (ordered)
- Verification per slice
- Dependencies
