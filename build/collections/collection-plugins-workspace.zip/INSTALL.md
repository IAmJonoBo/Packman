# INSTALL

## Collection plugins (workspace)

1. Unzip this archive into your repository root.
2. Merge the included .github/ content into your repository .github/.
3. Run validation: pnpm --filter packman-cli exec node dist/index.js validate . --strict
