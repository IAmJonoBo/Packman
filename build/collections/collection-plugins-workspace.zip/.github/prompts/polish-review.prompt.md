---
name: "brief:polish-review"
description: "Review a polish/refactor diff for value, risk, churn, and missed details."
agent: Polish Gate Reviewer
---

Target: ${selection}

Output:

- Findings (ranked)
- Must-fix vs nice-to-have
- Verification checklist
