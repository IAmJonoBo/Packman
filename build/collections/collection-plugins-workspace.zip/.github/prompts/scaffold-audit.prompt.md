---
name: "brief:scaffold-audit"
description: >-
  Audit an existing scaffold for missing lifecycle touchpoints and coherence;
  propose fixes.
agent: Scaffold Auditor
---

Target: ${selection}

Output:

- Missing items (ranked)
- Quick fixes (small diffs)
- Follow-up improvements
