---
name: ui:award
description: Art-direct and implement a meticulous, award-level UI system (typography/layout/colour/components).
agent: "Award-Winning UI Director"
---

Brief: ${selection}

Do:

- Ask for brand constraints and references.
- Produce tokens, grid/spacing, typography scale, component system, states.
- Provide pixel-perfect implementation guidance.
