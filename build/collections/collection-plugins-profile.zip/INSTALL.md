# INSTALL

## Collection plugins (profile/global)

1. Unzip this archive into a reusable profile folder.
2. Point VS Code settings to the agents/prompts/instructions folders from this archive.
