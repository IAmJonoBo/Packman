---
name: "brief:threat-model"
description: Produce a threat model + abuse cases + mitigations for the selected change.
agent: Threat Modeler
---

Target: ${selection}

Output:

- Assets/boundaries
- STRIDE table + abuse cases
- Mitigations + verification
