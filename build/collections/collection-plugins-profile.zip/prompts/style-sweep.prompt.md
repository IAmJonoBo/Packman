---
name: "brief:style-sweep"
description: >-
  Enforce Oxford English + Google dev style conventions; remove ambiguity and
  fix terminology.
agent: Style Enforcer
---

Target: ${selection}

Output:

- Issues found
- Changes applied
- Notes on terminology and glossary updates needed
