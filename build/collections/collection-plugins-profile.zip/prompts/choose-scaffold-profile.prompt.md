---
name: "brief:choose-scaffold-profile"
description: Select a standard scaffold profile from the catalogue based on the brief.
agent: Scaffold Profile Selector
---

Brief: ${selection}

Output:

- profile ID + name
- why this profile
- trade-offs
- next steps
