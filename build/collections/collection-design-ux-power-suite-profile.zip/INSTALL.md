# INSTALL

## Collection Design Ux Power Suite (profile/global)

1. Unzip this archive into a reusable profile folder (for example <path-to-your-copilot-assets>).
2. Point VS Code settings to these folders using settings.snippet.json.
3. Required keys:
   - chat.agentFilesLocations
   - chat.promptFilesLocations
   - chat.instructionsFilesLocations

This export is OS-agnostic and uses placeholder paths only.
