---
name: ship:pr-ready
description: "Prepare a PR-ready summary: what/why/how to test/risk/docs impact."
agent: "ask"
---

Output a PR-ready message:

## What / Why

-

## How to test

-

## Risk & impact

-

## Docs impact

-

## Notes for reviewers

-
