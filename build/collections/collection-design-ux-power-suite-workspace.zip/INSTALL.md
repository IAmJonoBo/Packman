# INSTALL

## Collection Design Ux Power Suite (workspace)

1. Unzip this archive into your repository root.
2. Merge the included .github/ content into your repository .github/.
3. Validate with:
   - pnpm --filter packman-cli exec node dist/index.js validate ./Packs --strict

This export targets VS Code default discovery paths under .github/.
