---
name: "brief:contract-tests"
description: >-
  Add contract tests for interface boundaries (schemas/types) and wire them into
  CI/test commands.
agent: Contract Tester
---

Target boundary: ${selection}

Output:

- Boundary summary
- Contract tests added
- How to run
