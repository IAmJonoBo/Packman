---
name: polish:ship
description: "Polish pass: nits that matter → safe refactors → consistency → gate review."
agent: "Polish & Tightening Engineer"
---

Scope: ${selection}

Do:

- Rank high-impact paper-cuts.
- Slice into small CLs.
- Apply safe refactors and a minimal consistency pass.
- Provide verification.

Output: improvements + remaining opportunities.
