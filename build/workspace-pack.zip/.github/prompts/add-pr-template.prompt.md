---
name: "brief:add-pr-template"
description: >-
  Add or improve the pull request template to enforce verification, risk, and
  docs impact.
agent: Template Curator
---

Target: ${selection}

Output:

- PR template path
- Sections and rationale
