---
name: "brief:add-issue-forms"
description: "Add structured GitHub issue forms for bugs, features, and docs."
agent: Template Curator
---

Target: ${selection}

Output:

- Issue forms added
- Keys/fields rationale
- Links to contributing guidance
